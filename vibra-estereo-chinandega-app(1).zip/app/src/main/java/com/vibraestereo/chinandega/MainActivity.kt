package com.vibraestereo.chinandega

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var isPlaying = false
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private val bg = Color.rgb(12, 10, 24)
    private val card = Color.rgb(30, 22, 48)
    private val pink = Color.rgb(255, 70, 166)
    private val purple = Color.rgb(168, 90, 255)
    private val streamUrl = "https://stream.zeno.fm/if4dwpcsxuvuv"
    private val radioUrl = "https://zeno.fm/radio/vibra-estereo-chinandega/"
    private val youtubeUrl = "https://youtube.com/@vibraestereochinandega"
    private val facebookUrl = "https://www.facebook.com/share/1CE386FxM2/"
    private val whatsappUrl = "https://wa.me/50585878934"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun rounded(color: Int, radius: Float = 24f, stroke: Int? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != null) setStroke(2, stroke)
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20, 22, 20, 24)
        }

        val logo = TextView(this).apply {
            text = "♫"
            textSize = 38f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(pink, purple, Color.rgb(50, 150, 255))
            ).apply { shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams(94, 94).apply { bottomMargin = 12 }
        }
        content.addView(logo)

        content.addView(text("VIBRA ESTÉREO", 27f, Color.WHITE, true))
        content.addView(text("CHINANDEGA", 17f, Color.rgb(90, 235, 150), true))
        content.addView(text("TU MÚSICA • TU COMPAÑÍA • TU CONEXIÓN", 10f, Color.LTGRAY).apply {
            setPadding(0, 8, 0, 22)
        })

        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 22, 18, 22)
            background = rounded(card, 28f, purple)
        }
        playerCard.addView(text("●  TRANSMITIENDO EN VIVO", 13f, pink, true))
        playerCard.addView(text("RADIO EN VIVO", 24f, Color.WHITE, true).apply {
            setPadding(0, 18, 0, 6)
        })
        playerCard.addView(text("SIÉNTELO • VÍVELO • COMPÁRTELO", 11f, Color.LTGRAY))
        playButton = Button(this).apply {
            text = "▶  ESCUCHAR EN VIVO"
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(purple, 40f)
            setOnClickListener { toggleRadio() }
        }
        playerCard.addView(playButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 58
        ).apply { topMargin = 20 })
        status = text("Tu compañía, dondequiera que estés", 12f, Color.LTGRAY).apply {
            setPadding(0, 12, 0, 0)
        }
        playerCard.addView(status)
        content.addView(playerCard, matchWidth().apply { bottomMargin = 18 })

        content.addView(sectionTitle("CONECTA CON VIBRA"))
        addAction(content, "📺", "VIBRA TV", "Videos y transmisiones", youtubeUrl)
        addAction(content, "🤝", "PATROCINADORES", "Nuestros aliados", null)
        addAction(content, "f", "FACEBOOK", "Síguenos en Facebook", facebookUrl)
        addAction(content, "☎", "WHATSAPP", "Escríbenos directamente", whatsappUrl)
        addAction(content, "↗", "COMPARTIR APLICACIÓN", "Invita a tus amigos", null) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT,
                    "¡Comparte la app de Vibra Estéreo! La música nos une. ¡Invita a tus amigos a vivir la experiencia Vibra! $radioUrl")
            }
            startActivity(Intent.createChooser(send, "Compartir aplicación"))
        }
        addAction(content, "⚙", "ADMINISTRACIÓN", "Acceso protegido", null) { showAdmin() }

        content.addView(text("UNA MARCA DE PRODUCCIONES Y EVENTOS ANDINO AGUIRRE", 9f, Color.GRAY).apply {
            setPadding(4, 22, 4, 8)
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun sectionTitle(title: String) = text(title, 13f, pink, true).apply {
        gravity = Gravity.START
        setPadding(4, 6, 4, 10)
    }

    private fun addAction(
        parent: LinearLayout, symbol: String, title: String, subtitle: String,
        url: String?, custom: (() -> Unit)? = null
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 12, 14, 12)
            background = rounded(card, 20f)
            isClickable = true
            isFocusable = true
        }
        val icon = text(symbol, 23f, purple, true)
        row.addView(icon, LinearLayout.LayoutParams(48, 48))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 14f, Color.WHITE, true).apply { gravity = Gravity.START })
        labels.addView(text(subtitle, 11f, Color.LTGRAY).apply { gravity = Gravity.START })
        row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener {
            when {
                custom != null -> custom()
                url != null -> openUrl(url)
                title == "PATROCINADORES" -> showSponsors()
            }
        }
        parent.addView(row, matchWidth().apply { bottomMargin = 10 })
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "No se pudo abrir el enlace", Toast.LENGTH_SHORT).show() }
    }

    private fun showSponsors() {
        AlertDialog.Builder(this)
            .setTitle("Patrocinadores de Vibra")
            .setMessage("Próximamente encontrarás aquí a nuestros patrocinadores y aliados.")
            .setPositiveButton("Cerrar", null)
            .show()
    }

    private fun showAdmin() {
        val prefs = getSharedPreferences("vibra_admin", MODE_PRIVATE)
        val savedPin = prefs.getString("pin", null)
        val field = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = if (savedPin == null) "Crea un PIN de 4 a 8 dígitos" else "Introduce tu PIN"
        }
        AlertDialog.Builder(this)
            .setTitle(if (savedPin == null) "Configurar administración" else "Panel administrativo")
            .setMessage(if (savedPin == null) "Crea un PIN local para proteger esta pantalla." else "Acceso protegido")
            .setView(field)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton(if (savedPin == null) "Guardar PIN" else "Entrar") { _, _ ->
                val entered = field.text.toString()
                if (savedPin == null) {
                    if (entered.length in 4..8 && entered.all { it.isDigit() }) {
                        prefs.edit().putString("pin", entered).apply()
                        Toast.makeText(this, "PIN configurado en este teléfono", Toast.LENGTH_LONG).show()
                    } else Toast.makeText(this, "El PIN debe tener de 4 a 8 números", Toast.LENGTH_LONG).show()
                } else if (entered == savedPin) {
                    AlertDialog.Builder(this).setTitle("Administración")
                        .setMessage("Panel local preparado. La gestión remota de patrocinadores y contenidos requiere un servicio seguro.")
                        .setPositiveButton("Cerrar", null).show()
                } else Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun toggleRadio() {
        if (isPlaying) {
            player?.release()
            player = null
            isPlaying = false
            playButton.text = "▶  ESCUCHAR EN VIVO"
            status.text = "Radio detenida"
            return
        }
        playButton.isEnabled = false
        status.text = "Conectando con la radio..."
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
                setDataSource(streamUrl)
                setOnPreparedListener {
                    start()
                    isPlaying = true
                    playButton.text = "■  DETENER RADIO"
                    playButton.isEnabled = true
                    status.text = "¡Estás escuchando Vibra Estéreo!"
                }
                setOnErrorListener { _, _, _ ->
                    isPlaying = false
                    playButton.isEnabled = true
                    status.text = "No se pudo conectar. Intenta de nuevo."
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            playButton.isEnabled = true
            status.text = "Error al conectar con la emisora"
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

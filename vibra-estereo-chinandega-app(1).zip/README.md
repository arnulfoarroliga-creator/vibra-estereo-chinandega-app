# Vibra Estéreo Chinandega

Proyecto Android de la aplicación de Vibra Estéreo Chinandega.

## Compilar gratis con GitHub Actions
1. Sube todo el contenido de este proyecto a la raíz de un repositorio GitHub.
2. Abre la pestaña **Actions**.
3. Selecciona **Crear APK Vibra Estereo** y pulsa **Run workflow** (o espera al primer push).
4. Al terminar, abre la ejecución y descarga el artefacto **Vibra-Estereo-APK**.

## Datos
- Stream: https://stream.zeno.fm/if4dwpcsxuvuv
- Radio: https://zeno.fm/radio/vibra-estereo-chinandega/
- YouTube: https://youtube.com/@vibraestereochinandega
- Facebook: https://www.facebook.com/share/1CE386FxM2/
- WhatsApp: https://wa.me/50585878934

## Nota
La reproducción está implementada para la pantalla activa. La reproducción en segundo plano no está incluida todavía. El panel administrativo usa un PIN local del teléfono y no sustituye un sistema remoto seguro. El logo oficial se puede incorporar como recurso gráfico en una actualización.
